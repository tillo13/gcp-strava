from flask import escape
import requests
import psycopg2
from psycopg2 import OperationalError
import os
import sqlalchemy
import config
from google.cloud import secretmanager
from config import STRAVA_CLIENT_ID, STRAVA_CLIENT_SECRET, STRAVA_TOKEN_URL, GCP_PROJECT_ID, GOOGLE_SECRET_DB_ID

def get_secret_version(project_id, secret_id, version_id="latest"):
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_id}/versions/{version_id}"
    response = client.access_secret_version(name=name)
    return response.payload.data.decode('UTF-8')

def create_conn():
    # Use same DB configuration as your flask app
    db_user = 'postgres'
    db_pass = get_secret_version(GCP_PROJECT_ID, GOOGLE_SECRET_DB_ID)  # Get DB_PASSWORD securely using Secret Manager.
    db_name = 'gcp_strava_data'
    cloud_sql_connection_name = 'gcp-strava:us-central1:gcp-default'

    db_url = sqlalchemy.engine.url.URL(
        drivername='postgresql+psycopg2',
        username=db_user,
        password=db_pass,
        database=db_name,
        host=f'/cloudsql/{cloud_sql_connection_name}'
    )

    engine = sqlalchemy.create_engine(db_url)
    return engine.connect()

def refresh_strava_tokens(request):
    request = request.get_json(silent=True)

    conn = create_conn()

    with conn:
        result = conn.execute("SELECT athlete_id, refresh_token FROM strava_access_tokens")
        athletes = result.fetchall()

    for athlete_id, refresh_token in athletes:
        payload = {
            'client_id': STRAVA_CLIENT_ID,
            'client_secret': STRAVA_CLIENT_SECRET,
            'refresh_token': refresh_token,
            'grant_type': 'refresh_token'
        }
        
        response = requests.post(STRAVA_TOKEN_URL, params=payload)

        if response.status_code == 200:
            new_access_token = response.json()['access_token']
            new_refresh_token = response.json()['refresh_token']
            new_expires_at = response.json()['expires_at']

            with conn:
                conn.execute("""
                        UPDATE strava_access_tokens
                        SET access_token = :access_token, 
                            refresh_token = :refresh_token, 
                            expires_at = :expires_at,
                            last_updated = now()
                        WHERE athlete_id = :athlete_id
                        """, 
                        {'access_token': new_access_token, 'refresh_token': new_refresh_token, 'expires_at': new_expires_at, 'athlete_id': athlete_id})

        else:
            return f'Failed to refresh token for athlete {athlete_id}: {response.json()}'

    return 'Successfully updated tokens.'